package Ejercicio02_ListinTelefonico;

//Nodo del árbol de búsqueda binaria: un contacto y sus dos hijos.
public class Nodo {
    Contacto dato;
    Nodo izq, der;

    Nodo(Contacto dato) {
        this.dato = dato;
    }
}