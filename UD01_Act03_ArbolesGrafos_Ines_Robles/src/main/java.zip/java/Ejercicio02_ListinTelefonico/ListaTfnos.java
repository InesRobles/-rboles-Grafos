package Ejercicio02_ListinTelefonico;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

//Lista telefónica. El HashMap por teléfono permite buscar por teléfono en O(1) y garantiza que sea único.
public class ListaTfnos {
    private Nodo raiz;
    private final Map<String, Contacto> porTelefono = new HashMap<>();

    //Minúsculas y sin tildes (Depuración).
    static String norm(String s) {
        String n = Normalizer.normalize(s.trim(), Normalizer.Form.NFD);
        return n.replaceAll("\\p{M}", "").toLowerCase();
    }

    //Orden total: apellidos, nombre y, si coinciden, teléfono.
    static int comparar(Contacto a, Contacto b) {
        int c = norm(a.apellidos).compareTo(norm(b.apellidos));
        if (c != 0) return c;
        c = norm(a.nombre).compareTo(norm(b.nombre));
        if (c != 0) return c;
        return a.telefono.compareTo(b.telefono);
    }

    // Función que da de alta a cada contacto
    public boolean alta(Contacto c) {
        if (c.nombre.isBlank() || c.apellidos.isBlank() || c.telefono.isBlank()) return false;
        if (porTelefono.containsKey(c.telefono)) return false;// teléfono único
        raiz = insertar(raiz, c);
        porTelefono.put(c.telefono, c);
        return true;
    }

    private Nodo insertar(Nodo n, Contacto c) {
        if (n == null) return new Nodo(c);
        if (comparar(c, n.dato) < 0) n.izq = insertar(n.izq, c);
        else  n.der = insertar(n.der, c);
        return n;
    }

    //Función que da de baja los contactos
    public boolean baja(String telefono) {
        Contacto c = porTelefono.remove(telefono);
        if (c == null) return false;
        raiz = eliminar(raiz, c);
        return true;
    }

    private Nodo eliminar(Nodo n, Contacto c) {
        if (n == null) return null;
        int cmp = comparar(c, n.dato);
        if (cmp < 0)  n.izq = eliminar(n.izq, c);
        else if (cmp > 0) n.der = eliminar(n.der, c);
        else {
            if (n.izq == null) return n.der;
            if (n.der == null) return n.izq;
            Nodo sucesor = n.der;
            while (sucesor.izq != null) sucesor = sucesor.izq;
            n.dato = sucesor.dato;
            n.der = eliminar(n.der, sucesor.dato);
        }
        return n;
    }

    //Función para modificar el número de teléfono
    public boolean modificar(String telefonoActual, String nombre, String apellidos,
                             String telefonoNuevo, String email) {
        Contacto viejo = porTelefono.get(telefonoActual);
        if (viejo == null) return false;
        if (!telefonoNuevo.equals(telefonoActual) && porTelefono.containsKey(telefonoNuevo))
            return false;                             // el nuevo teléfono ya existe
        baja(telefonoActual);
        alta(new Contacto(nombre, apellidos, telefonoNuevo, email));
        return true;
    }

    // Función que busca por teléfono: O(1) gracias al índice hash. */
    public Contacto buscarPorTelefono(String tel) {
        return porTelefono.get(tel);
    }

    //Función que busca por apellidos y nombre.
    public List<Contacto> buscarPorNombre(String apellidos, String nombre) {
        List<Contacto> res = new ArrayList<>();
        buscarNombre(raiz, norm(apellidos), norm(nombre), res);
        return res;
    }

    private void buscarNombre(Nodo n, String ap, String nom, List<Contacto> res) {
        if (n == null) return;
        int c = norm(n.dato.apellidos).compareTo(ap);
        if (c == 0) c = norm(n.dato.nombre).compareTo(nom);
        if (c == 0) res.add(n.dato);
        if (c >= 0) buscarNombre(n.izq, ap, nom, res);
        if (c <= 0) buscarNombre(n.der, ap, nom, res);
    }

    //Prefijo de apellidos: equivale al rango [p, p + carácter máximo].
    public List<Contacto> buscarPorPrefijo(String prefijo) {
        String p = norm(prefijo);
        return buscarRango(p, p + Character.MAX_VALUE);
    }

    // Rango alfabético de apellidos, ambos extremos incluidos.
    public List<Contacto> buscarRango(String desde, String hasta) {
        List<Contacto> res = new ArrayList<>();
        rango(raiz, norm(desde), norm(hasta), res);
        return res;
    }

    // Inorden podando ramas fuera de rango: el resultado sale ya ordenado
    private void rango(Nodo n, String lo, String hi, List<Contacto> res) {
        if (n == null) return;
        String ap = norm(n.dato.apellidos);
        if (lo.compareTo(ap) <= 0) rango(n.izq, lo, hi, res);
        if (lo.compareTo(ap) <= 0 && ap.compareTo(hi) <= 0) res.add(n.dato);
        if (hi.compareTo(ap) >= 0) rango(n.der, lo, hi, res);
    }

    // Listado completo ordenado
    public List<Contacto> listar() {
        List<Contacto> res = new ArrayList<>();
        inorden(raiz, res);
        return res;
    }

    private void inorden(Nodo n, List<Contacto> res) {
        if (n == null) return;
        inorden(n.izq, res);
        res.add(n.dato);
        inorden(n.der, res);
    }
}