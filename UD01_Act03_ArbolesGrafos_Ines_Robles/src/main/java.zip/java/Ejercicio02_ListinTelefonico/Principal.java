package Ejercicio02_ListinTelefonico;
import java.util.List;
import java.util.Scanner;

public class Principal {

    static void mostrar(List<Contacto> lista) {
        if (lista.isEmpty()) {
            System.out.println("Sin resultados");
            return;
        }
        lista.forEach(c -> System.out.println("  " + c));
    }

    static String pedir(Scanner scan, String msg) {
        System.out.print(msg);
        return scan.hasNextLine() ? scan.nextLine().trim() : "";
    }

    public static void main(String[] args) {
        ListaTfnos listin = new ListaTfnos();
        // Datos de ejemplo
        listin.alta(new Contacto("Ana", "García López", "600111222", "ana@mail.com"));
        listin.alta(new Contacto("Luis", "García Pérez", "600333444", ""));
        listin.alta(new Contacto("María", "Martínez Ruiz", "600555666", "maria@mail.com"));
        listin.alta(new Contacto("Pedro", "Alonso Gil", "600777888", ""));
        listin.alta(new Contacto("Sara", "Zapata Mora", "600999000", "sara@mail.com"));

        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("\n--- LISTÍN TELEFÓNICO ---");
            System.out.println("1) Alta");
            System.out.println("2) Baja");
            System.out.println("3) Modificar");
            System.out.println("4) Buscar por teléfono");
            System.out.println("5) Buscar por apellidos+nombre");
            System.out.println("6) Buscar por prefijo");
            System.out.println("7) Buscar por rango");
            System.out.println("8) Mostrar todos los contactos");
            System.out.println("0) Salir");
            String op = pedir(sc, "Opción: ");

            switch (op) {
                case "1" -> {
                    Contacto c = new Contacto(pedir(sc, "Nombre: "), pedir(sc, "Apellidos: "),
                            pedir(sc, "Teléfono: "), pedir(sc, "Email (opcional): "));
                    System.out.println(listin.alta(c) ? "Contacto añadido."
                            : "No se pudo añadir (datos vacíos o teléfono repetido).");
                }
                case "2" -> System.out.println(listin.baja(pedir(sc, "Teléfono a borrar: "))
                        ? "Contacto eliminado." : "No existe ese teléfono.");
                case "3" -> {
                    String tel = pedir(sc, "Teléfono del contacto a modificar: ");
                    Contacto actual = listin.buscarPorTelefono(tel);
                    if (actual == null) {
                        System.out.println("No existe ese teléfono.");
                        break;
                    }
                    System.out.println("Actual: " + actual + "\n(deja vacío para mantener)");
                    String nom = pedir(sc, "Nombre: ");     if (nom.isEmpty()) nom = actual.nombre;
                    String ape = pedir(sc, "Apellidos: ");  if (ape.isEmpty()) ape = actual.apellidos;
                    String tn  = pedir(sc, "Teléfono: ");   if (tn.isEmpty())  tn  = actual.telefono;
                    String em  = pedir(sc, "Email: ");      if (em.isEmpty())  em  = actual.email;
                    System.out.println(listin.modificar(tel, nom, ape, tn, em)
                            ? "Contacto modificado." : "No se pudo modificar (teléfono nuevo repetido).");
                }
                case "4" -> {
                    Contacto c = listin.buscarPorTelefono(pedir(sc, "Teléfono: "));
                    System.out.println(c == null ? "  (no encontrado)" : "  " + c);
                }
                case "5"-> mostrar(listin.buscarPorNombre(pedir(sc, "Apellidos: "), pedir(sc, "Nombre: ")));
                case "6"-> mostrar(listin.buscarPorPrefijo(pedir(sc, "Prefijo de apellidos: ")));
                case "7"-> mostrar(listin.buscarRango(pedir(sc, "Desde: "), pedir(sc, "Hasta: ")));
                case "8"-> mostrar(listin.listar());
                case "0"-> {
                    System.out.println("Hasta pronto.");
                    return;
                }
                default -> System.out.println("Opción no válida.");
            }
        }
    }
}
