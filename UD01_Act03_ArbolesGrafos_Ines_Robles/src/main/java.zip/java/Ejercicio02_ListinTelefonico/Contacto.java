package Ejercicio02_ListinTelefonico;

//Clase plantilla de contactos
public class Contacto {
    String nombre, apellidos, telefono, email;

    public Contacto(String nombre, String apellidos, String telefono, String email) {
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.telefono = telefono;
        this.email = (email == null) ? "" : email;
    }

    @Override
    public String toString() {
        return String.format("%s, %s | Tel: %s | Email: %s",
                apellidos, nombre, telefono, email.isEmpty() ? "-" : email);
    }
}
