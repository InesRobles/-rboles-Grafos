package Ejercicio01_ArbolLetras;
import java.util.Scanner;

public class Principal {
    public static void main(String[] args) {
        ArbolLetras arbol = new ArbolLetras("ABCDEFGHIJKLMNO");
        System.out.println("~~~ Árbol de letras ~~~");
        arbol.mostrarPorNiveles();

        Scanner scan = new Scanner(System.in);
        while (true) {
            System.out.print("Introduce una letra: ");
            if (!scan.hasNextLine()) {
                break;
            }
            String entrada = scan.nextLine().trim();
        //Depuración por si no introduce nada, o más de una letra.
            if (entrada.isEmpty()||entrada.length() != 1 || !Character.isLetter(entrada.charAt(0))) {
                System.out.println("Error, introduce solo una letra.");
                continue;
            }

            char letra =Character.toUpperCase(entrada.charAt(0));
            Ruta ruta =arbol.buscar(letra);
            if (ruta == null) {
                System.out.println("La letra " + letra + "no esta en el árbol.");
            } else {
                System.out.println("Letras vistas: " + ruta.letras);
                System.out.println("Direcciones: " + (ruta.direcciones.isEmpty() ? "(es la raíz)" : ruta.direcciones));
            }
        }
    }
}