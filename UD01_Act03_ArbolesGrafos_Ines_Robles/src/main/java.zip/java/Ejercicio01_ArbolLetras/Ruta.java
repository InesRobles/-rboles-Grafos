package Ejercicio01_ArbolLetras;
import java.util.ArrayList;
import java.util.List;

// Letras visitadas y direcciones tomadas.
public class Ruta {
    final List<Character> letras =new ArrayList<>();
    final List<Character> direcciones =new ArrayList<>();
}