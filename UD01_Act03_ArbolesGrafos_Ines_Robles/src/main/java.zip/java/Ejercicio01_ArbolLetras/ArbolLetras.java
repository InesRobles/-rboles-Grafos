package Ejercicio01_ArbolLetras;
import java.util.LinkedList;
import java.util.Queue;

public class ArbolLetras {
    private final Nodo raiz;
    // Construcción del árbol rellenando de izquierda a derecha y de nivel en nivel.
    public ArbolLetras(String letras) {
        if (letras ==null || letras.isEmpty()) {
            raiz =null;
            return;
        }
        raiz =new Nodo(letras.charAt(0));
        Queue<Nodo> cola =new LinkedList<>();
        cola.add(raiz);
        int i =1;
        while (i < letras.length()) {
            Nodo actual = cola.poll();
            actual.izq = new Nodo(letras.charAt(i++));
            cola.add(actual.izq);
            if (i < letras.length()) {
                actual.der = new Nodo(letras.charAt(i++));
                cola.add(actual.der);
            }
        }
    }

    //Función que devuelve la ruta desde la raíz hasta la letra, o null si no existe esa letra.
    public Ruta buscar(char objetivo) {
        Ruta ruta =new Ruta();
        return dfs(raiz, objetivo, ruta) ? ruta : null;
    }
// Función que recorre el árbol.
    private boolean dfs(Nodo nodo, char objetivo, Ruta ruta) {
        if (nodo == null) return false;
        ruta.letras.add(nodo.letra); // visito el nodo
        if (nodo.letra == objetivo)
            return true; // Si es el nodo, prueba a la izquierda
        ruta.direcciones.add('I');
        if (dfs(nodo.izq, objetivo, ruta))
            return true; //Sino, puerba a la derecha
        ruta.direcciones.remove(ruta.direcciones.size() - 1);
        ruta.direcciones.add('D');
        if (dfs(nodo.der, objetivo, ruta)) return true;
        ruta.direcciones.remove(ruta.direcciones.size() - 1);
        ruta.letras.remove(ruta.letras.size() - 1);
        return false;
    }

    // Función que muestra el árbol por niveles.
    public void mostrarPorNiveles() {
        //Depuración por si estuviera vacio.
        if (raiz == null) {
            System.out.println("Árbol vacío");
            return;
        }
        Queue<Nodo> cola = new LinkedList<>();
        cola.add(raiz);
        int nivel = 0;
        while (!cola.isEmpty()) {
            int tam = cola.size();
            StringBuilder sb = new StringBuilder("Nivel " + nivel + ": ");
            for (int i = 0; i < tam; i++) {
                Nodo n = cola.poll();
                sb.append(n.letra).append(' ');
                if (n.izq != null) cola.add(n.izq);
                if (n.der != null) cola.add(n.der);
            }
            System.out.println(sb.toString().trim());
            nivel++;
        }
    }
}