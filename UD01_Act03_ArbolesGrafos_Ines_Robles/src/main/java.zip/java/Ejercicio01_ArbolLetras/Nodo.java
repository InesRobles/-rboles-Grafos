package Ejercicio01_ArbolLetras;

/** Nodo del árbol binario: una letra y punteros a los hijos izquierdo y derecho. */
public class Nodo {
    char letra;
    Nodo izq, der;
    Nodo(char letra) {
        this.letra = letra;
    }
}