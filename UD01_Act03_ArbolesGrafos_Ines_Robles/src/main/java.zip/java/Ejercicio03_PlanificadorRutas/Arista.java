package Ejercicio03_PlanificadorRutas;
//Camino, con su modo, su línea (si es transporte) y su duración.
public record Arista(String destino, Transporte modo, String linea, int minutos) {}