package Ejercicio03_PlanificadorRutas;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

//Grafo.
public class Grafo {
    final Map<String, List<Arista>> ady = new TreeMap<>();

    //Camino de un solo sentido
    public void dirigida(String a, String b, Transporte m, String linea, int min) {
        ady.computeIfAbsent(a, k -> new ArrayList<>()).add(new Arista(b, m, linea, min));
        ady.computeIfAbsent(b, k -> new ArrayList<>());
    }

    //Camino de doble sentido
    public void doble(String a, String b, Transporte m, String linea, int min) {
        dirigida(a, b, m, linea, min);
        dirigida(b, a, m, linea, min);
    }
}