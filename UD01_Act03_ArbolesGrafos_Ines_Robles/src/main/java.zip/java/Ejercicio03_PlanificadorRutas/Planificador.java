package Ejercicio03_PlanificadorRutas;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;

import static Ejercicio03_PlanificadorRutas.Transporte.BUS;
import static Ejercicio03_PlanificadorRutas.Transporte.METRO;

//Calcula la ruta más óptima con Dijkstra.

public class Planificador {
    //Tiempo real de una arista según la hora punta.
    static int tiempo(Arista a, Opciones op) {
        if (!op.horaPunta()) return a.minutos();
        return switch (a.modo()) {
            case BUS -> (int) Math.round(a.minutos() * 1.5); // atascos
            case METRO-> (int) Math.round(a.minutos() * 1.25);// andenes llenos
            default-> a.minutos();
        };
    }

    //Devuelve el último Paso de la ruta óptima, o null si no hay ruta.
    public static Transporte calcular(Grafo g, String origen, String destino, Opciones op) {
        PriorityQueue<Transporte> cola =new PriorityQueue<>(Comparator.comparingInt(p -> p.coste));
        Map<Estado, Integer> mejor =new HashMap<>();
        Transporte inicio =new Transporte(new Estado(origen, ""), null, null, 0, 0, 0);
        cola.add(inicio);
        mejor.put(inicio.estado, 0);

        while (!cola.isEmpty()) {
            Ruta actual =cola.poll();
            if (actual.coste > mejor.getOrDefault(actual.estado, Integer.MAX_VALUE)) continue;
            if (actual.estado.lugar().equals(destino)) return actual;// primer pop = óptimo

            for (Arista a : g.ady.getOrDefault(actual.estado.lugar(), List.of())) {
                if (op.evitar().contains(a.modo())) continue;// restricción de modo
                String linea =actual.estado.ultimaLinea();
                int transb =actual.transbordos;
                int coste =actual.coste + tiempo(a, op);

                if (a.modo().esTransporte()) {
                    // Transbordo=subir a una línea distinta de la última usada
                    if (!linea.isEmpty() && !linea.equals(a.linea())) {
                        transb++;
                        coste += op.penalizacionTransbordo();
                    }
                    linea = a.linea();
                }

                Estado nuevo = new Estado(a.destino(), linea);
                if (coste < mejor.getOrDefault(nuevo, Integer.MAX_VALUE)) {
                    mejor.put(nuevo, coste);
                    cola.add(new Ruta(nuevo, actual, a, coste,actual.minutos + tiempo(a, op), transb));
                }
            }
        }
        return null; //Para cuando no hay rutas posibles.
    }
}