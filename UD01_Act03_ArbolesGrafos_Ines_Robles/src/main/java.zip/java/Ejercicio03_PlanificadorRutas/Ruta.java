package Ejercicio03_PlanificadorRutas;

//Lista de como se llegó a un estado y a qué coste.
public class Ruta {
    final Estado estado;
    final Ruta anterior;
    final Arista via;
    final int coste; //min + penalizaciones.
    final int minutos; // tiempo real.
    final int transbordos;

   public Ruta(Estado estado, Ruta anterior, Arista via, int coste, int minutos, int transbordos) {
        this.estado =estado;
        this.anterior =anterior;
        this.via =via;
        this.coste =coste;
        this.minutos =minutos;
        this.transbordos =transbordos;
    }
}