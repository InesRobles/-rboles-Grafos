package Ejercicio03_PlanificadorRutas;

//Transportes de la ciudad.
public enum Transporte {
    PIE, BICI, BUS, METRO;

    //Transportes con transbordos.
    public boolean esTransporte() {
        return this==BUS ||this==METRO;
    }
}