package Ejercicio03_PlanificadorRutas;
import java.util.Set;

//Restricciones elegidas por el usuario.
public record Opciones(Set<Transporte> evitar, int penalizacionTransbordo, boolean horaPunta) {}
