package Ejercicio03_PlanificadorRutas;

//Estado (Dónde estoy y cuál fue la última línea de transporte usada)
public record Estado(String lugar, String ultimaLinea) {}